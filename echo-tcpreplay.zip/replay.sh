#!/bin/bash

tcpreplay --topspeed --intf1=eth0 $1